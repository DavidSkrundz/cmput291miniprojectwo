# cmput291miniprojectwo
optional


# How to run

cat <file> | python3 main1.py
./main2.sh
python3 main3.py
python3 main4.py
