import queryparser

if __name__ == "__main__":
	try:
		queryparser.askForQuery()
	except:
		print('')