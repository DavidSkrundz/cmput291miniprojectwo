sort pterms.txt --unique > sorted_pterms.txt
sort rterms.txt --unique > sorted_rterms.txt
sort scores.txt --unique > sorted_scores.txt
cat reviews.txt > sorted_reviews.txt